#include <stdio.h>

void main(){
	int meses,anios,edad;
	printf("INGRESA TU EDAD.\n\n");
	printf("A�os: ");
	scanf("%d",&meses);
	printf("Meses: ");
	scanf("%d",&anios);
	edad = (anios * 12) + meses;
	printf("Tu edad en meses es: %d\n\n",edad);
}
